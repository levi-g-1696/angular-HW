export interface Isinger{
Name: string;
LastName:string;
Age:number;

Songs:string[];
PictureLink:string
}