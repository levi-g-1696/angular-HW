import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Singer1Component } from './singer1.component';

describe('Singer1Component', () => {
  let component: Singer1Component;
  let fixture: ComponentFixture<Singer1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Singer1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Singer1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
