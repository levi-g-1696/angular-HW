import { Component, OnInit } from '@angular/core';
import { Isinger } from './Isinger';

@Component({
  selector: 'app-singer1',
  templateUrl: './singer1.component.html',
  styleUrls: ['./singer1.component.css']
})
export class Singer1Component implements OnInit {

  constructor() { }
singer10:Isinger={
  Name :"Shuli",
  LastName:"Rand",
  Age:61,
  Songs: ['ayeka','arafel'] ,
  PictureLink:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm39-NGr6nZpmM2feYqy4WstaikFuIP3pT4w&usqp=CAU"


}
  ngOnInit(): void {
    console.log (this.singer10.Songs[0])
  }

}
