import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-picture',
  templateUrl: './picture.component.html',
  styleUrls: ['./picture.component.css']
})
export class PictureComponent implements OnInit {
piclink:any="https://www.army-technology.com/wp-content/uploads/sites/3/2022/02/T-64BV.-Credit-Wikimedia-1.jpg"
  constructor() { }

  ngOnInit(): void {
  }

}
