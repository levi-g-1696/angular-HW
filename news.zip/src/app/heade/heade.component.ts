import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heade',
  templateUrl: './heade.component.html',
  styleUrls: ['./heade.component.css']
})
export class HeadeComponent implements OnInit {
date:any = "9 March 2022"
num: number= 1001


  constructor() { }

  ngOnInit(): void {
  }

}
