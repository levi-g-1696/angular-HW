import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {

getArticle1(a:any){
  return "Russian troops have been in control of the Zaporizhzhia plant, the largest in Europe, since seizing it an attack on Friday that set a building on fire and raised fears of a nuclear disaster. It was later determined that no radiation was released."
}
  constructor() { }

  ngOnInit(): void {
  }

}
